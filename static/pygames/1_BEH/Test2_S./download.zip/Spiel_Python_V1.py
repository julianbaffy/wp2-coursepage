import pgzrun
import random

WIDTH = 600
HEIGHT = 600
TITLE = "APG SpaceShooter V1"

raumschiff=Actor("baer1.png")
raumschiff.x=60
raumschiff.y=300

aliens=[]
herzen=[]
asteroiden=[]
raketen=[]

leben=100
punkte=0

def on_key_down(key):
    if key==keys.SPACE:
        rakete=Actor("rakete.png", pos=(raumschiff.x+30,raumschiff.y+33))
        raketen.append(rakete)

def alien_erzeugen():
    alien=Actor("alien.png", pos=(600,random.randint(0,600)))
    aliens.append(alien)

def herz_erzeugen():
    herz=Actor("herz.png", pos=(600, random.randint(0,600)))
    herzen.append(herz)

def asteroid_erzeugen():
    asteroid=Actor("asteroid.png", pos=(600, random.randint(0,600)))
    asteroiden.append(asteroid)

def update():
    global leben
    global punkte

    if keyboard.up:
        if raumschiff.y<0:
            raumschiff.y=600
        else:
            raumschiff.y=raumschiff.y-3

    elif keyboard.down:
        if raumschiff.y>600:
            raumschiff.y=0
        else:
            raumschiff.y=raumschiff.y+3

    for alien in aliens:
        alien.x=alien.x-3

        if alien.x<0:
            aliens.remove(alien)

        if raumschiff.colliderect(alien):
            aliens.remove(alien)
            if leben !=0:
                leben=leben-10

        for rakete in raketen:
            if rakete.colliderect(alien):
                raketen.remove(rakete)
                aliens.remove(alien)
                if leben>0:
                    punkte=punkte+50

    for herz in herzen:
        herz.x=herz.x-10

        if herz.x<0:
            herzen.remove(herz)

        if raumschiff.colliderect(herz):
            herzen.remove(herz)
            if leben<100 and leben>0:
                leben=leben+15

    for rakete in raketen:
        rakete.x=rakete.x+5
        if rakete.x>600:
            raketen.remove(rakete)

    for asteroid in asteroiden:
        asteroid.x=asteroid.x-7

        if asteroid.x<0:
            asteroiden.remove(asteroid)

        if raumschiff.colliderect(asteroid):
            asteroiden.remove(asteroid)
            if leben<=100 and leben>0:
                leben=leben-15

        for rakete in raketen:
            if rakete.colliderect(asteroid):
                raketen.remove(rakete)
                asteroiden.remove(asteroid)
                if leben>0:
                    punkte=punkte+100

def draw():
    screen.blit("hintergrund.gif",(0,0))

    raumschiff.draw()

    for alien in aliens:
        alien.draw()

    for asteroid in asteroiden:
        asteroid.draw()

    for herz in herzen:
        herz.draw()

    if leben<=0:
        screen.draw.text('GAME OVER', centerx=300, centery=300, color=(255,255,255), fontname="pixels.ttf", fontsize=120)

    for rakete in raketen:
        rakete.draw()

    screen.draw.text('Leben ' + str(leben)+'/100', (15,10), color=(255,255,255), fontname="pixels.ttf", fontsize=60)
    screen.draw.text('Punkte ' + str(punkte), (350,10), color=(255,255,255), fontname="pixels.ttf", fontsize=60)

clock.schedule_interval(alien_erzeugen,random.randint(0,3))
clock.schedule_interval(herz_erzeugen,random.randint(5,10))
clock.schedule_interval(asteroid_erzeugen, random.randint(1,5))

pgzrun.go()